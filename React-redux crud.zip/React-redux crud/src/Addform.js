import React from 'react';


import { connect } from 'react-redux';

class Addform extends React.Component{

    formSubmit(e){
        e.preventDefault();
        let name = this.refs.name.value;
        let address = this.refs.address.value;

        let data = { name, address};

        console.log("data", data);

        this.props.dispatch({ type: 'ADD_DATA', data: data});  //To dispatch an action to reducer
        this.refs.name.value = '';
        this.refs.address.value = '';
    }

    render(){
        return(
            <div>
            <h1>Add Details</h1>
                <form className="detailsForm" name="myForm" onSubmit={(e)=> this.formSubmit(e)} >
                    <label className="">Enter Name:</label><input type="text" className="form-control" ref="name" name="name"/><br/>
                    <label className="">Enter Address:</label><textarea rows="5" cols="50" className="form-control" ref="address" name="address"/><br/>
                    <button type="submit">Submit</button>
                </form>
            </div>
        );
    }
}

export default connect()(Addform);
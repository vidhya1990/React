const studentReducer = (state = [], action) => {
    switch (action.type){
        case 'ADD_DATA':
            return state.concat([action.data]); 
        default:
            return state;
    }
}

export default studentReducer;


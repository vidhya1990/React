import React from 'react';
import logo from './logo.svg';
import './App.css';
import Addform from './Addform';
import List from './List';

class App extends React.Component{
  render(){
    return(
      <div className="App">
        <h1>React Redux Crud Example</h1>
        <Addform />
        <List />

      </div>
    );
  }
}
 
 
export default App;

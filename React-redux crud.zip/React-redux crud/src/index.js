import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

import { createStore } from 'redux';  


import studentReducer from './reducers/studentReducer'; 

import { Provider } from 'react-redux';  // Provider is to pass state object to component without need to pass props
 
const store = createStore(studentReducer);  // To create store(use createStore()) and passing reducer as argument and cont is passed as a props to component

ReactDOM.render(
<Provider store= {store}> 
<App /> 
</Provider>, document.getElementById('root'));




//<Provider store= {store}> -- Store is callad to components as a props using provider, </provider> is wrapped with <app> to use store by all components
        

serviceWorker.unregister();

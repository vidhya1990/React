import React from 'react';


import { connect } from 'react-redux';

const mapStateToProps = (state) => {
    return {
        result : state
    }
}

class List extends React.Component{
    render(){
        return(
            <div className="vidhya">
                <h1>Student List</h1>
                 <table>
                    <thead>
                        <tr>
                            <th>S.NO</th><th>Name</th><th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.result.map((res) => <tr><td>{res.id}</td></tr>
                                <tr><td> {res.name}</td></tr>
                                <tr><td>{res.address}</td></tr>
             
                        )}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default connect(mapStateToProps) (List);